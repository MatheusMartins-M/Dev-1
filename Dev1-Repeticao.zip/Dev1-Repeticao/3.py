soma = 0

for x in range(23, 56):
    soma += x

    print(x)

print(soma)
