valor = int(input())

for x in range (0, valor):
    print(valor, end = " ")

