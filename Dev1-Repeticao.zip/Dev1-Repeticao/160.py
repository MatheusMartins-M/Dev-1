chico = 150
juca = 110
contador = 0

while juca <= chico:
    juca += 3
    chico += 2
    contador += 1

print("Serão necessários {0} anos".format(contador))