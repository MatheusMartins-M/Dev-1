for x in range(100, 0, -1):
    print(x)