for x in range (1, 101):
    print(x)