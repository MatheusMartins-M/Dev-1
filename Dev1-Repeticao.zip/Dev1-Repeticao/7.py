soma = 0

for x in range (20, 51):
    if x % 2 != 0:
        soma += x
        print(x)

print(soma)