for x in range (1, 601):
    if x % 13 == 0 or x % 17 == 0:
        print(x, end = " ")