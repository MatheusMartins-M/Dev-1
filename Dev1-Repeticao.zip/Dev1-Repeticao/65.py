for x in range (1, 16):
    quadrado = x ** 2

    print("O quadrado do número {0} é {1}".format(x, quadrado))
